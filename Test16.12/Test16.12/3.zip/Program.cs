﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Chep
{
    class Program
    {
        static void Main(string[] args)
        {
            Graph graph = ReadGraph();

            int startNode = int.Parse(Console.ReadLine());
            int endNode = int.Parse(Console.ReadLine());

            bool pathExists = graph.HasPath(startNode, endNode);

            if (pathExists)
            {
                Console.WriteLine($"Path from {startNode} to {endNode} is found");
            }
            else
            {
                Console.WriteLine($"Path from {startNode} to {endNode} is not found");
            }
        }

        public static Graph ReadGraph()
        {
            int totalVertices = int.Parse(Console.ReadLine());
            int totalEdges = int.Parse(Console.ReadLine());

            Graph graph = new Graph(totalVertices);

            for (int i = 0; i < totalEdges; i++)
            {
                int[] edgeInput = Console.ReadLine().Split().Select(int.Parse).ToArray();

                graph.AddEdge(edgeInput[0], edgeInput[1]);
            }

            return graph;
        }
    }

    class Graph
    {
        private readonly List<int>[] _adjacencyList;

        public Graph(int totalVertices)
        {
            _adjacencyList = new List<int>[totalVertices];
            for (int i = 0; i < _adjacencyList.Length; i++)
            {
                _adjacencyList[i] = new List<int>();
            }
        }

        public void AddEdge(int fromVertex, int toVertex)
        {
            _adjacencyList[fromVertex].Add(toVertex);
        }

        public bool HasPath(int startVertex, int endVertex)
        {
            bool[] visitedNodes = new bool[_adjacencyList.Length];

            return PerformDFS(startVertex, endVertex, visitedNodes);
        }

        private bool PerformDFS(int currentVertex, int targetVertex, bool[] visitedNodes)
        {
            if (currentVertex == targetVertex)
            {
                return true;
            }

            visitedNodes[currentVertex] = true;

            foreach (var neighbor in _adjacencyList[currentVertex])
            {
                if (!visitedNodes[neighbor])
                {
                    if (PerformDFS(neighbor, targetVertex, visitedNodes))
                    {
                        return true;
                    }
                }
            }

            return false;
        }
    }
}
